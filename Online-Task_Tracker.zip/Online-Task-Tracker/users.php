<?php
session_start();
if (!isset($_SESSION['user']) || empty($_SESSION['is_admin'])) {
  header("Location: login.php");
  exit();
}
require 'db.php';
?>


<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registered Users</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
  <div class="page-wrapper">
  <main class="card-style">
    <h2>All Registered Users</h2>
    <table class="user-table">
      <thead>
        <tr><th>ID</th><th>Name</th><th>Email</th></tr>
      </thead>
      <tbody>
        <?php
        $stmt = $pdo->query("SELECT id, name, email FROM users");
        while ($row = $stmt->fetch()):
        ?>
          <tr>
            <td><?= $row['id']; ?></td>
            <td><?= htmlspecialchars($row['name']); ?></td>
            <td><?= htmlspecialchars($row['email']); ?></td>
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </main>
  <script src="js/main.js"></script>
  </div>
</body>
<?php include 'includes/footer.php'; ?>
</html>
