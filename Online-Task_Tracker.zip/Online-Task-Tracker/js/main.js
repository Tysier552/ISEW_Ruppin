function showMessage() {
  document.getElementById("message").innerText = "Thanks for visiting!";
}

function validateLogin(event) {
  event.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const pass = document.getElementById("loginPassword").value;

  if (email && pass.length >= 4) {
    document.getElementById("formMessage").innerText = "Login successful (fake)";
  } else {
    document.getElementById("formMessage").innerText = "Invalid login data!";
  }
}

function validateRegister(event) {
  event.preventDefault();
  const name = document.getElementById("regName").value;
  const email = document.getElementById("regEmail").value;
  const pass = document.getElementById("regPassword").value;

  if (name.length > 1 && email && pass.length >= 4) {
    document.getElementById("formMessage").innerText = "Registered successfully (fake)";
  } else {
    document.getElementById("formMessage").innerText = "Please fill all fields correctly!";
  }
}

function teamGreeting() {
  const el = document.getElementById("teamMessage");
  if (el) el.innerText = "You're viewing the team page. Thanks for visiting!";
}

function sayHello() {
  const el = document.getElementById("helloMsg");
  if (el) el.innerText = "Hello from Tysier! 👋";
}

//  Time-based greeting for homepage
function displayGreeting() {
  const hour = new Date().getHours();
  let msg = "Good Evening!";
  if (hour < 12) msg = "Good Morning!";
  else if (hour < 18) msg = "Good Afternoon!";
  const greetingEl = document.getElementById("greetingMessage");
  if (greetingEl) greetingEl.innerText = msg;
}

//  View My Board Button Logic (Controlled by server hint)
function setupBoardRedirect(isLoggedIn) {
  const btn = document.querySelector(".cta-btn");
  if (btn) {
    btn.addEventListener("click", () => {
      if (isLoggedIn) {
        window.location.href = "board.php";
      } else {
        alert("You're not logged in. Redirecting to login...");
        window.location.href = "login.php";
      }
    });
  }
}

function toggleNav() {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  sidebar.classList.toggle('active');
  overlay.classList.toggle('active');
}

