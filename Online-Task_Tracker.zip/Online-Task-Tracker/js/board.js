let currentDate = null;

// Open modal
function openTaskForm(dateKey) {
  currentDate = dateKey;
  document.getElementById("taskDateInput").value = dateKey;
  document.getElementById("taskModal").style.display = "flex";
  const now = new Date().toISOString().slice(0, 16);
  document.querySelector("[name='deadline']").min = now;
}

// Close modal
function closeTaskForm() {
  document.getElementById("taskModal").style.display = "none";
  document.getElementById("addTaskForm").reset();
  const now = new Date().toISOString().slice(0, 16);
  document.querySelector("[name='deadline']").min = now;

}

// Submit task
document.getElementById("addTaskForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(this);
  formData.append("start_time", new Date().toISOString());

  fetch("php/task_add.php", {
    method: "POST",
    body: formData
  })
  .then(res => res.text())
  .then(response => {
    if (response === "OK") {
      closeTaskForm();
      setTimeout(loadTasks, 300);
    } else {
      alert("Error: " + response);
    }
  });
});

document.getElementById("editTaskForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(this);
  fetch("php/task_edit.php", {
    method: "POST",
    body: formData
  }).then(res => res.text())
    .then(() => {
      closeEditForm();
      loadTasks();
    });
});


function loadTasks() {
  fetch("php/task_fetch.php")
    .then(res => res.json())
    .then(data => {
      // Clear all lists
      document.querySelectorAll('.task-list').forEach(list => list.innerHTML = '');
      const ongoingList = document.getElementById("ongoingTasks");
      const completedList = document.getElementById("completedTasks");
      const deletedList = document.getElementById("deletedTasks");
      if (ongoingList) ongoingList.innerHTML = '';
      if (completedList) completedList.innerHTML = '';
      if (deletedList) deletedList.innerHTML = '';

      const tasksPerDay = {};

      data.forEach(task => {
        const li = document.createElement("li");
        li.className = "task-item";
        li.style.padding = "10px";
        li.style.borderRadius = "6px";
        li.style.marginBottom = "10px";

        // Style by type
        if (task.is_deleted == 1) {
          li.style.backgroundColor = "#ff3e3e33"; // red
        } else if (task.is_completed == 1) {
          li.style.backgroundColor = "#4caf5044"; // green
        } else {
          li.style.backgroundColor = "#ffffff22"; // gray ongoing
        }

        // Inner content
        li.innerHTML = `
          <strong>${task.task_name}</strong><br>
          ${new Date(task.deadline).toLocaleString()}<br>
          ${task.description || ''}
          <div class="task-actions">
            ${task.is_completed == 0 && task.is_deleted == 0 ? `
              <button onclick="markComplete(${task.id})">✅</button>
              <button class="edit-btn" data-task='${JSON.stringify(task).replace(/'/g, "&apos;")}'>✏️</button>
              <button onclick="deleteTask(${task.id})">🗑️</button>
            ` : ''}
          </div>
        `;

        // Attach edit listener
        setTimeout(() => {
          document.querySelectorAll(".edit-btn").forEach(btn => {
            btn.addEventListener("click", e => {
              const task = JSON.parse(e.currentTarget.getAttribute("data-task").replace(/&apos;/g, "'"));
              editTask(task);
            });
          });
        }, 50);

        // Append to correct section
        if (task.is_deleted == 1) {
          deletedList?.appendChild(li);
        } else if (task.is_completed == 1) {
          completedList?.appendChild(li);
        } else {
          const date = task.task_date;
          if (!tasksPerDay[date]) tasksPerDay[date] = 0;
          tasksPerDay[date]++;
          const list = document.getElementById("tasks-" + date);
          list?.appendChild(li);
        }
      });

      // Disable add if full
      document.querySelectorAll('.day-column').forEach(col => {
        const date = col.getAttribute("data-date");
        const count = tasksPerDay[date] || 0;
        const btn = col.querySelector(".add-task-btn");
        btn.disabled = count >= 10;
        btn.title = count >= 10 ? "Max 10 tasks reached" : "";
      });
    });
}


function markComplete(taskId) {
  fetch("php/task_complete.php?id=" + taskId)
    .then(() => loadTasks());
}

function deleteTask(taskId) {
  document.getElementById("deleteTaskId").value = taskId;
  document.getElementById("deleteModal").style.display = "flex";
}

function closeDeleteModal() {
  document.getElementById("deleteModal").style.display = "none";
  document.getElementById("deleteTaskId").value = '';
}

function confirmDelete() {
  const id = document.getElementById("deleteTaskId").value;
  fetch("php/task_delete.php?id=" + id).then(() => {
    closeDeleteModal();
    loadTasks();
  });
}


function editTask(task) {
  document.getElementById("editTaskId").value = task.id;
  document.getElementById("editTaskName").value = task.task_name;
  document.getElementById("editDeadline").value = task.deadline.replace(" ", "T");
  const now = new Date().toISOString().slice(0, 16);
  document.getElementById("editDeadline").min = now;
  document.getElementById("editDescription").value = task.description || '';
  document.getElementById("editModal").style.display = "flex";
}


function closeEditForm() {
  document.getElementById("editModal").style.display = "none";
  document.getElementById("editTaskForm").reset();
}


document.addEventListener("DOMContentLoaded", loadTasks);

