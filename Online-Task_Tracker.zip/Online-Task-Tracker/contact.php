<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
  <div class="page-wrapper">
  <main class="card-style">
    <h2>Contact us and we will get back to you.</h2>
    <form action="mailto:zidantysier87@gmail.com" method="post" enctype="text/plain"  class="form-section card-style">
      <label>Name:</label>
      <input type="text" name="name" required>
      <label>Email:</label>
      <input type="email" name="email" required>
      <label>Message:</label>
      <textarea name="message" rows="5" required></textarea>
      <input type="submit" value="Send">
    </form>
  </main>
  </div>
  <script src="js/main.js"></script>
</body>
<?php include 'includes/footer.php'; ?>
</html>
