<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user'])) exit;

$id = $_POST['id'];
$name = $_POST['task_name'];
$desc = $_POST['description'];
$deadline = $_POST['deadline'];

$stmt = $pdo->prepare("UPDATE tasks SET task_name = ?, description = ?, deadline = ? WHERE id = ? AND user_id = (SELECT id FROM users WHERE email = ?)");
$stmt->execute([$name, $desc, $deadline, $id, $_SESSION['user']]);
