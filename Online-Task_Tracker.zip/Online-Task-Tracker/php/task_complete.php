<?php
session_start();
require '../db.php';

$id = $_GET['id'] ?? null;
if (!$id || !isset($_SESSION['user'])) exit;

$stmt = $pdo->prepare("UPDATE tasks
  SET is_completed = 1
  WHERE id = ? AND user_id = (SELECT id FROM users WHERE email = ?)");
$stmt->execute([$id, $_SESSION['user']]);
