<?php
session_start();
require '../db.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user'])) {
  echo json_encode(["error" => "Not logged in"]);
  exit;
}

$email = $_SESSION['user'];
$today = date("Y-m-d");
$end = date("Y-m-d", strtotime("+6 days"));

try {
  // Look up the user's ID by their email
  $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
  $stmt->execute([$email]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$user) {
    echo json_encode(["error" => "User not found"]);
    exit;
  }

  $user_id = $user['id'];

  // Get tasks for the next 7 days
  $stmt = $pdo->prepare("
    SELECT id, task_name, description, start_time, deadline,
       DATE(start_time) AS task_date,
       is_completed, is_deleted
    FROM tasks
    WHERE user_id = ? AND (
        DATE(start_time) BETWEEN ? AND ?
            OR is_completed = 1
            OR is_deleted = 1
        )
        ORDER BY is_completed ASC, is_deleted ASC, deadline ASC

        ");
  $stmt->execute([$user_id, $today, $end]);
  $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

  echo json_encode($tasks);
} catch (PDOException $e) {
  echo json_encode(["error" => $e->getMessage()]);
}
