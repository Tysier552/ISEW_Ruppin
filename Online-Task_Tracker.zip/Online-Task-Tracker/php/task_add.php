<?php
session_start();
require '../db.php';

if (!isset($_SESSION['user'])) {
  exit("Unauthorized");
}

$email = $_SESSION['user'];
$name = $_POST['task_name'] ?? '';
$description = $_POST['description'] ?? '';
$start = $_POST['start_time'] ?? '';
$deadline = $_POST['deadline'] ?? '';

if (!$name || !$start || !$deadline) {
  exit("Missing fields");
}

try {
  // Get the user's ID from their email
  $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
  $stmt->execute([$email]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);

  if (!$user) {
    exit("User not found");
  }

  $user_id = $user['id'];

  // Insert the new task
  $stmt = $pdo->prepare("
    INSERT INTO tasks (user_id, task_name, description, start_time, deadline)
    VALUES (?, ?, ?, ?, ?)
  ");
  $stmt->execute([$user_id, $name, $description, $start, $deadline]);

  echo "OK";
} catch (PDOException $e) {
  echo "DB Error: " . $e->getMessage();
}
