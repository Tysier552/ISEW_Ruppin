<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Online Task Tracker</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
<div class="page-wrapper">
  <main  class="card-style">
    <div class="centered-logo">
        <img src="assets/logo.png" alt="Online Task Tracker Logo" class="centered-site-logo">
    </div>

    <h1 class="hero-title">Welcome to Online Task Tracker</h1>
    <p id="greetingMessage" class="greeting-text"></p>
  </main>

  <script src="js/main.js"></script>
  <script>
    displayGreeting();
  </script>
  <section class="feature-list-section">
  <h3>Why Use Online Task Tracker?</h3>
  <ul class="feature-list">
    <li>✅ Easy registration and login</li>
    <li>📋 Track your personal tasks and goals</li>
    <li>🧑‍🤝‍🧑 Collaborate with your team</li>
    <li>💡 Fully responsive and interactive design</li>
    <li>📧 Contact the team directly through the app</li>
  </ul>
</section>
<section class="feature-list-section">
    <h3> First time visiting? Register down here!</h3>
     <form action="register.php" method="POST" class="form-section card-style">
      <label>Full Name:</label>
      <input type="text" name="name" required>
      <label>Email:</label>
      <input type="email" name="email" required>
      <label>Password:</label>
      <input type="password" name="password" required>
      <input type="submit" value="Register">
    </form>
</section>
<section class="developer-section">
  <h3>Meet the Developer 👨‍💻</h3>
  <div class="dev-card">
    <img src="assets/profile1.png" alt="Tysier Zidan">
    <div class="dev-info">
      <p><strong>Name:</strong> Tysier Zidan</p>
      <p><strong>Email:</strong> <a href="mailto:zidantysier87@gmail.com">zidantysier87@gmail.com</a></p>
      <p><strong>Role:</strong> Full Stack Developer</p>
      <p><strong>Languages:</strong> PHP, JavaScript, HTML, CSS, SQL</p>
      <p><strong> <a href="https://github.com/Tysier552/ISEW_Ruppin"> Github Link</a></p>
      <p><strong><a href="https://www.linkedin.com/in/tysier-zidan/">Linked In </a></p>
    </div>
  </div>
</section>
</div>
</body>
<?php include 'includes/footer.php'; ?>
</html>
