<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}

require 'db.php';

$email = $_SESSION['user'];
$stmt = $pdo->prepare("SELECT name FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$name = $user ? $user['name'] : 'User';
?>

<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Home</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
  <div class="page-wrapper">
    <main class="card-style">
      <h2>Welcome, <?php echo htmlspecialchars($name); ?>!</h2>
      <p>You can view your board or profile.</p>

      <p><strong><a href="board.php"><button>Go to Board</button></a></strong></p>
      <p><strong><a href="profile.php"><button>My Profile</button></a></strong></p>
    </main>
    <script src="js/main.js"></script>
  </div>
</body>
<?php include 'includes/footer.php'; ?>
</html>
