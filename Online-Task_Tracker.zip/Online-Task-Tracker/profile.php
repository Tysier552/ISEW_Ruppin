<?php
session_start();
if (!isset($_SESSION['user'])) {
  header("Location: login.php");
  exit();
}
require 'db.php';

$currentEmail = $_SESSION['user'];
$success = '';
$error = '';

// Handle update form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $newEmail = $_POST['email'];
  $newPass = $_POST['password'];

  if (strlen($newPass) < 4) {
    $error = "Password must be at least 4 characters.";
  } else {
    $hashed = password_hash($newPass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET email = ?, password = ? WHERE email = ?");
    $stmt->execute([$newEmail, $hashed, $currentEmail]);

    $_SESSION['user'] = $newEmail;
    $currentEmail = $newEmail;
    $success = "Profile updated successfully!";
  }
}

// Get name
$stmt = $pdo->prepare("SELECT name FROM users WHERE email = ?");
$stmt->execute([$currentEmail]);
$user = $stmt->fetch();
?>

<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Profile</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
<div class="page-wrapper">
  <main class="card-style">
    <h2>My Profile</h2>
    <?php if ($success): ?><p style="color:lightgreen;"><?= $success ?></p><?php endif; ?>
    <?php if ($error): ?><p style="color:#ff9999;"><?= $error ?></p><?php endif; ?>

    <form method="POST">
      <p><strong>Full Name:</strong> <?= htmlspecialchars($user['name']) ?></p>

      <label for="email">Email:</label>
      <input type="email" name="email" value="<?= htmlspecialchars($currentEmail) ?>" required>

      <label for="password">New Password:</label>
      <input type="password" name="password" placeholder="Enter new password" required>

      <input type="submit" value="Update Info">
    </form>
  </main>
  <script src="js/main.js"></script>
  </div>
</body>
<?php include 'includes/footer.php'; ?>
</html>
