<?php
session_start();
if (!isset($_SESSION['user'])) {
  header('Location: login.php');
  exit();
}
include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Task Board</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
  <div class="page-wrapper">
    <h1 class="hero-title">
        Your Task Board<br>
    <span class="date-subtitle">
     <?php echo date("l, F j, Y"); ?>
    </span>
    </h1>

    <div id="calendar-board" class="calendar-board">
      <?php
      date_default_timezone_set('Asia/Jerusalem');
      for ($i = 0; $i < 7; $i++):
        $dayLabel = date("l, M j", strtotime("+$i days"));
        $dateKey = date("Y-m-d", strtotime("+$i days"));
      ?>
        <div class="day-column" data-date="<?= $dateKey ?>">
          <h3><?= $dayLabel ?></h3>
          <ul class="task-list" id="tasks-<?= $dateKey ?>"></ul>
          <button class="add-task-btn" onclick="openTaskForm('<?= $dateKey ?>')">+ Add Task</button>
        </div>
      <?php endfor; ?>
    </div>
    <section class="card-style">
        <h3>✅ Completed Tasks</h3>
        <ul id="completedTasks" class="task-list"></ul>
    </section>

    <section class="card-style">
        <h3>🗑️ Deleted Tasks</h3>
        <ul id="deletedTasks" class="task-list"></ul>
    </section>

  </div>
    <script src="js/main.js"></script>
  <!-- Add Task  -->
  <div id="taskModal" class="modal">
    <div class="modal-content card-style">
      <span class="close" onclick="closeTaskForm()">&times;</span>
      <h2>Add Task</h2>
      <form id="addTaskForm">
        <input type="hidden" name="task_date" id="taskDateInput">
        <label>Task Name:</label>
        <input type="text" name="task_name" required>
        <label>Deadline:</label>
        <input type="datetime-local" name="deadline" required>
        <label>Description:</label>
        <textarea name="description" rows="3"></textarea>
        <button type="submit">Save Task</button>
      </form>
    </div>
  </div>
   <!-- Edit Task  -->
<div id="editModal" class="modal">
  <div class="modal-content card-style">
    <span class="close" onclick="closeEditForm()">&times;</span>
    <h2>Edit Task</h2>
    <form id="editTaskForm">
      <input type="hidden" name="task_id" id="editTaskId">
      <label>Task Name:</label>
      <input type="text" name="task_name" id="editTaskName" required>
      <label>Deadline:</label>
      <input type="datetime-local" name="deadline" id="editDeadline" required>
      <label>Description:</label>
      <textarea name="description" id="editDescription" rows="3"></textarea>
      <button type="submit">Update Task</button>
    </form>
  </div>
</div>

 <!-- Delete Task Modal -->
<div id="deleteModal" class="modal">
  <div class="modal-content card-style">
    <span class="close" onclick="closeDeleteModal()">&times;</span>
    <h2>Delete Task?</h2>
    <p>Are you sure you want to delete this task?</p>
    <input type="hidden" id="deleteTaskId">
    <div style="margin-top: 15px;">
      <button onclick="confirmDelete()" style="background-color: #ff4444;">Yes, Delete</button>
      <button onclick="closeDeleteModal()">Cancel</button>
    </div>
  </div>
</div>

  <?php include 'includes/footer.php'; ?>
  <script src="js/board.js"></script>
</body>
</html>
