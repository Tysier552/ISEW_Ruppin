<?php session_start(); ?>
<header class="main-header">
  <div class="navbar">
    <div class="hamburger" onclick="toggleNav()">&#9776;</div>
  </div>

  <div id="sidebar" class="sidebar">
    <nav class="nav-links">
      <?php if (!isset($_SESSION['user'])): ?>
        <a href="index.php">Home</a>
        <a href="contact.php">Contact</a>
        <a href="login.php">Login</a>
      <?php else: ?>
        <a href="index.php">Home</a>
        <a href="contact.php">Contact</a>
        <a href="userhome.php">My Profile</a>
        <a href="board.php">Board</a>
        <?php if (!empty($_SESSION['is_admin'])): ?>
          <a href="users.php">Users</a>
        <?php endif; ?>
        <a href="logout.php">Logout</a>
      <?php endif; ?>
    </nav>
  </div>
  <div id="overlay" class="overlay" onclick="toggleNav()"></div>
</header>
