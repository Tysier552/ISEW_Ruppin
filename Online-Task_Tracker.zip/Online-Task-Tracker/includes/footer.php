<footer>
  <p>&copy; <?php echo date("Y"); ?> Online Task Tracker. All rights reserved.</p>

  <div class="footer-links">
    <a href="https://github.com/Tysier552/ISEW_Ruppin" target="_blank">
      <img src="assets/github.png" alt="GitHub">
    </a>
    
    <a href="https://www.ruppin.ac.il" target="_blank">
      <img src="assets/ruppin.png" alt="Ruppin">
    </a>
  </div>
</footer>
