<?php
$host = 'sql204.byethost6.com';
$db   = 'b6_39110733_a';
$user = 'b6_39110733';
$pass = 'Tysier211'; 

try {
  $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Connection failed: " . $e->getMessage());
}
?>
