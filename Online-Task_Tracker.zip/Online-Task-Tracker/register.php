<?php
session_start();
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

  $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
  try {
    $stmt->execute([$name, $email, $password]);
    $_SESSION['user'] = $email;
    header("Location: userhome.php");
    exit();
  } catch (PDOException $e) {
    $error = "Registration failed: " . $e->getMessage();
  }
}
?>

<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">  
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Register</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body class="animated-bg">
<div class="page-wrapper">
  <main class="card-style">
    <h2>Register</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form action="register.php" method="POST" class="form-section card-style">
      <label>Full Name:</label>
      <input type="text" name="name" required>
      <label>Email:</label>
      <input type="email" name="email" required>
      <label>Password:</label>
      <input type="password" name="password" required>
      <input type="submit" value="Register">
    </form>
  </main>
  <script src="js/main.js"></script>
  </div>
</body>
<?php include 'includes/footer.php'; ?>
</html>
